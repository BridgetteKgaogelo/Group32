<?php
session_start();
include 'DBConn.php';

// Security check
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: adminLogin.php");
    exit();
}

// Bullet 4.3: Delete Logic
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM Customer WHERE id = $id");
    header("Location: adminDashboard.php");
}

// Bullet 4.2: Verify Logic
if (isset($_GET['verify'])) {
    $id = $_GET['verify'];
    mysqli_query($conn, "UPDATE Customer SET status = 'verified' WHERE id = $id");
    header("Location: adminDashboard.php");
}

$result = mysqli_query($conn, "SELECT * FROM Customer");
?>


    <!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard | The Clothing Hub</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #eef2f7; margin: 0; padding: 20px; }
        .dashboard-container { max-width: 1000px; margin: auto; background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #333; border-bottom: 2px solid #4ecdc4; padding-bottom: 10px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th { background-color: #333; color: white; padding: 12px; text-align: left; }
        td { padding: 12px; border-bottom: 1px solid #ddd; }
        tr:hover { background-color: #f9f9f9; }
        .status-pending { color: #e67e22; font-weight: bold; }
        .status-verified { color: #27ae60; font-weight: bold; }
        .action-btn { padding: 5px 10px; text-decoration: none; border-radius: 4px; font-size: 13px; color: white; }
        .btn-verify { background: #27ae60; }
        .btn-update { background: #2980b9; }
        .btn-delete { background: #c0392b; }
        .add-btn { background: #333; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; display: inline-block; margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <h1>Admin Control Center</h1>
        <p>Logged in as: <strong><?php echo $_SESSION['admin_name']; ?></strong> | <a href="index.php">Logout</a></p>
        
        <a href="register.php" class="add-btn">+ Add New Customer</a>

        <table>
            <tr>
                <th>Full Name</th>
                <th>Email</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <tr>
                <td><?php echo $row['fullname']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td>
                    <span class="<?php echo ($row['status'] == 'pending') ? 'status-pending' : 'status-verified'; ?>">
                        <?php echo strtoupper($row['status']); ?>
                    </span>
                </td>
                <td>
                    <?php if ($row['status'] == 'pending'): ?>
                        <a href="adminDashboard.php?verify=<?php echo $row['id']; ?>" class="action-btn btn-verify">Verify</a> 
                    <?php endif; ?>
                    <a href="updateCustomer.php?id=<?php echo $row['id']; ?>" class="action-btn btn-update">Update</a> 
                    <a href="adminDashboard.php?delete=<?php echo $row['id']; ?>" class="action-btn btn-delete" onclick="return confirm('Delete this user?')">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>     