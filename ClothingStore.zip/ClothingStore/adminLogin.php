<?php
session_start();
include 'DBConn.php';

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Updated credentials based on latest user data
    if ($email === "lizzy.m@clothingstore.co.za" && $password === "LizzyPass123") {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_name'] = "Lizzy";
        header("Location: adminDashboard.php");
        exit();
    } else {
        $error = "Invalid administrator credentials.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login | Past Times</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
    <style>
        :root { --forest: #1d3c34; --gold: #a68a64; --cream: #f9f7f2; }
        body { 
            margin: 0; font-family: 'Montserrat', sans-serif; 
            background: linear-gradient(rgba(29,60,52,0.8), rgba(29,60,52,0.8)), url('https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&w=1500');
            background-size: cover; height: 100vh; display: flex; justify-content: center; align-items: center;
        }
        .login-card { background: white; padding: 50px; width: 380px; box-shadow: 20px 20px 0px var(--gold); text-align: center; }
        h2 { font-family: 'Playfair Display', serif; color: var(--forest); font-size: 2rem; margin-top: 0; }
        input { width: 100%; padding: 12px; margin: 10px 0; border: 1px solid #ddd; box-sizing: border-box; }
        .btn { background: var(--forest); color: white; width: 100%; padding: 15px; border: none; font-weight: bold; cursor: pointer; text-transform: uppercase; }
        .error { color: #d9534f; background: #fff1f0; padding: 10px; border: 1px solid #d9534f; margin-bottom: 20px; font-size: 0.8rem; }
    </style>
</head>
<body>
    <div class="login-card">
        <h2>Staff Login</h2>
        <?php if($error) echo "<div class='error'>$error</div>"; ?>
        <form method="POST">
            <input type="email" name="email" placeholder="Admin Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" class="btn">Verify Access</button>
        </form>
    </div>
</body>
</html>