<?php
include 'DBConn.php';

// Initialize variables for the Sticky Form
$errorMsg = "";
$typedUser = "";
$typedEmail = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $typedUser = $_POST['username'];
    $typedEmail = $_POST['email'];
    $typedPass = $_POST['password'];

    // Requirement: Compare password to hash in the table
    // Requirement: Verify if the user is a customer/verified
    $query = "SELECT * FROM Customer WHERE fullname = '$typedUser' AND email = '$typedEmail'";
    $result = mysqli_query($conn, $query);

    if ($user = mysqli_fetch_assoc($result)) {
        // Associative read: we check the 'status' column
        if ($user['status'] !== 'verified') {
            $errorMsg = "Your registration is still pending Admin verification.";
        } elseif ($typedPass === $user['password_hash']) {
            // Requirement: Display "User [Name] is logged in"
            echo "<h1>User " . $user['fullname'] . " is logged in</h1>";

            // Requirement: Associative read approach to display data
            echo "Email: " . $user['email'];
            exit();
        } else {
            $errorMsg = "Incorrect password.";
        }
    } else {
        $errorMsg = "User does not exist. Please register.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Past Times</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        :root { --forest-green: #1d3c34; --cream: #f9f7f2; --gold-accent: #a68a64; }
        body {
            margin: 0; font-family: 'Montserrat', sans-serif;
            background: linear-gradient(rgba(29, 60, 52, 0.7), rgba(29, 60, 52, 0.7)), 
                        url('https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1500');
            background-size: cover; background-position: center; height: 100vh;
            display: flex; justify-content: center; align-items: center;
        }
        .login-card { background: white; padding: 50px; width: 100%; max-width: 400px; box-shadow: 20px 20px 0px var(--gold-accent); text-align: center; }
        .login-card h2 { font-family: 'Playfair Display', serif; color: var(--forest-green); font-size: 2rem; margin-bottom: 10px; }
        .form-group { text-align: left; margin-bottom: 20px; }
        .form-group label { display: block; font-weight: 600; font-size: 0.8rem; margin-bottom: 5px; text-transform: uppercase; letter-spacing: 1px; }
        .form-group input { width: 100%; padding: 12px; border: 1px solid #ddd; box-sizing: border-box; }
        .btn-action { background: var(--forest-green); color: white; width: 100%; padding: 15px; border: none; font-weight: bold; text-transform: uppercase; cursor: pointer; }
        .link-footer { display: block; margin-top: 25px; color: var(--forest-green); text-decoration: none; font-size: 0.8rem; font-weight: 600; }
    </style>
</head>
<body>
    <div class="login-card">
        <h2>Customer Login</h2>
        <p>Welcome back to Past Times.</p>

        <form method="POST" action="">
            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" required>
            </div>
            <button type="submit" class="btn-action">Login</button>
        </form>
        <a href="register.php" class="link-footer">New here? Create an account</a>
    </div>
</body>
</html>