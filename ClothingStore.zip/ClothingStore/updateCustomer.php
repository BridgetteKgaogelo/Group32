<?php
session_start();
include 'DBConn.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: adminLogin.php");
    exit();
}

$id = $_GET['id'];
$res = mysqli_query($conn, "SELECT * FROM Customer WHERE id = $id");
$user = mysqli_fetch_assoc($res);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['fullname'];
    $email = $_POST['email'];
    $status = $_POST['status'];

    $sql = "UPDATE Customer SET fullname='$name', email='$email', status='$status' WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        header("Location: adminDashboard.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<body>
    <h2>Update Customer Details</h2>
    <form method="post">
        Full Name: <input type="text" name="fullname" value="<?php echo $user['fullname']; ?>"><br><br>
        Email: <input type="email" name="email" value="<?php echo $user['email']; ?>"><br><br>
        Status: 
        <select name="status">
            <option value="pending" <?php if ($user['status'] == 'pending')
                echo 'selected'; ?>>Pending</option>
            <option value="verified" <?php if ($user['status'] == 'verified')
                echo 'selected'; ?>>Verified</option>
        </select><br><br>
        <button type="submit">Save Changes</button>
    </form>
</body>
</html>