<?php
include 'DBConn.php';

// 1. Drop the table if it exists to start fresh
$dropSql = "DROP TABLE IF EXISTS Customer";
mysqli_query($conn, $dropSql);

// 2. Create the table structure (including role and status)
$createSql = "CREATE TABLE Customer (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    fullname VARCHAR(50) NOT NULL,
    email VARCHAR(50) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    role VARCHAR(20) DEFAULT 'customer'
)";

if (mysqli_query($conn, $createSql)) {
    echo "Table Customer created successfully.<br>";
}

// 3. Load the data from userData.txt
$file = fopen("userData.txt", "r");

while (($line = fgets($file)) !== false) {
    // Trim the line and split by commas
    $data = explode(",", trim($line));

    $name = $data[0];
    $email = $data[1];
    $pass = $data[2];
    $status = $data[3];
    $role = $data[4];

    $insertSql = "INSERT INTO Customer (fullname, email, password_hash, status, role) 
                  VALUES ('$name', '$email', '$pass', '$status', '$role')";

    mysqli_query($conn, $insertSql);
}

fclose($file);
echo "Data from userData.txt (The Project Team) loaded successfully.";
?>