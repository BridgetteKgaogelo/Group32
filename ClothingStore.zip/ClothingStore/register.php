<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Join Past Times</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
    <style>
        :root { --forest: #1d3c34; --gold: #a68a64; }
        body { 
            margin: 0; font-family: 'Montserrat', sans-serif; 
            background: linear-gradient(rgba(29,60,52,0.7), rgba(29,60,52,0.7)), url('https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?auto=format&fit=crop&w=1500');
            background-size: cover; height: 100vh; display: flex; justify-content: center; align-items: center;
        }
        .reg-card { background: white; padding: 40px; width: 450px; box-shadow: 20px 20px 0px var(--gold); text-align: center; }
        h2 { font-family: 'Playfair Display', serif; color: var(--forest); }
        input { width: 100%; padding: 10px; margin: 8px 0; border: 1px solid #ddd; box-sizing: border-box; }
        .btn { background: var(--forest); color: white; width: 100%; padding: 15px; border: none; font-weight: bold; cursor: pointer; margin-top: 10px;}
    </style>
</head>
<body>
    <div class="reg-card">
        <h2>Create Account</h2>
        <form action="process_register.php" method="POST">
            <input type="text" name="fullname" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email Address" required>
            <input type="password" name="password" placeholder="Create Password" required>
            <button type="submit" class="btn">Register Now</button>
        </form>
        <p><small>Already a member? <a href="login.php" style="color:var(--forest)">Login here</a></small></p>
    </div>
</body>
</html>